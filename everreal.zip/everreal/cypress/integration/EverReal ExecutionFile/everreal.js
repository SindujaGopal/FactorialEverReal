describe('Open factorial page', function () {
    it('Open factorial page', function () {
        cy.visit('factorial.html')
        cy.get('h1[class="margin-base-vertical text-center"]').should('have.text', 'EverReal\'s factorial calculator!').screenshot()
        cy.get('span[class="fa fa-calculator"]').should('be.visible')
        cy.get('span[class="fa fa-calculator"]').should('not.be.disabled')
        cy.get('#number').invoke('attr', 'placeholder').should('eq', 'Enter an integer')
        cy.get('#getFactorial').should('have.text', 'Calculate!')
    })
})

describe('Check page title', function () {
    it('Check page title', function () {
        cy.title().should('eq', 'Factorial')
    })
})

describe('Enter valid number and click calculate', function () {
    it('Enter valid number and click calculate', function () {
        cy.get('#number').clear()
        cy.get('#number').type('5').screenshot()
        cy.get('#getFactorial').click()
        cy.get('#getFactorial').invoke('attr', 'style').should('eq', 'opacity: 0.5;')
    })
})

describe('Check result displayed for valid entry', function () {
    it('Check result displayed for valid entry', function () {
        cy.screenshot()
        cy.get('#resultDiv').should('contain.text', 'The factorial is:')
    })
})

describe('Enter alphabet and click calculate', function () {
    it('Enter alphabet and click calculate', function () {
        cy.get('#number').clear()
        cy.get('#number').type('abcdef').screenshot()
        cy.get('#getFactorial').click()
        cy.get('#getFactorial').invoke('attr', 'style').should('eq', 'opacity: 0.5;')
        cy.get('#number').invoke('attr', 'style').should('eq', 'border: 2px solid red;')
        cy.get('#resultDiv').should('be.visible').should('have.text', 'Please enter an integer')
    })
})

describe('Enter special characters and click calculate', function () {
    it('Enter special characters and click calculate', function () {
        cy.screenshot()
        cy.get('#number').clear()
        cy.get('#number').type('abc(#&$&#').screenshot()
        cy.get('#getFactorial').click()
        cy.get('#getFactorial').invoke('attr', 'style').should('eq', 'opacity: 0.5;')
        cy.get('#number').invoke('attr', 'style').should('eq', 'border: 2px solid red;')
        cy.get('#resultDiv').should('be.visible').should('have.text', 'Please enter an integer')
    })
})

describe('Enter decimal and click calculate', function () {
    it('Enter decimal and click calculate', function () {
        cy.screenshot()
        cy.get('#number').type('4.6')
        cy.get('#getFactorial').click()
        cy.get('#getFactorial').invoke('attr', 'style').should('eq', 'opacity: 0.5;')
        cy.get('#number').invoke('attr', 'style').should('eq', 'border: 2px solid red;')
        cy.get('#resultDiv').should('be.visible').should('have.text', 'Please enter an integer')
    })
})

describe('Check Terms and Conditions navigation link', function () {
    it('Terms and Conditions navigation link should navigate to /terms URL', function () {
        cy.get('a[href="/terms"]').should('have.text', 'Terms and Conditions')
    })
})

describe('Click Terms and Conditions and check navigation', function () {
    it('Click on Terms and Conditions', function () {
        cy.get('a[href="/terms"]').click()
        cy.screenshot()
        cy.url().should('contain', '/terms')
        cy.title().should('eq', 'Terms and Conditions')

    })
})

describe('Check Privacy navigation link', function () {
    it('Privacy navigation link should navigate to /privacy URL', function () {
        cy.go('back')
        cy.get('a[href="/privacy"]').should('have.text', 'Privacy')
    })
})

describe('Click Privacy and check navigation', function () {
    it('Click on Privacy', function () {
        cy.get('a[href="/privacy"]').click()
        cy.screenshot()
        cy.url().should('contain', '/privacy')
        cy.title().should('eq', 'Privacy')
    })
})

describe('Check copyright section', function () {
    it('Check copyright section', function () {
        cy.go('back')
        cy.get('p[class="margin-base-vertical text-center copyright"]').eq(1).should('contain.text', 'EverReal')
        cy.get('p[class="margin-base-vertical text-center copyright"]').eq(1).should('contain.text', '2017')
        cy.get('p[class="margin-base-vertical text-center copyright"]').eq(1).should('contain.text', '-')
        cy.get('p[class="margin-base-vertical text-center copyright"]').eq(1).should('contain.text', '2021')
    })
})

describe('Click EverReal in copyright section', function () {
    it('Click on EverReal in copyright section', function () {
        cy.get('a[href="https://www.everreal.co"]').should('have.text', 'EverReal')
        cy.get('a[href="https://www.everreal.co"]').click()
        cy.screenshot()
        cy.url().should('eq', 'https://www.everreal.co/')

    })
})

